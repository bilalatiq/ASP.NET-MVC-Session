﻿using Session_Aleem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Session_Aleem.Controllers
{
    public class loginController : Controller
    {
        //
        // GET: /login/

        public ActionResult Index()
        {
            return View();

        }
        [HttpPost]
        public ActionResult Index(person p)
        {
            if (p.validate())
            {
                Session["ID"] = p;
                return RedirectToAction("Index", "Home");
            }
            return View();
        }

    }
}
