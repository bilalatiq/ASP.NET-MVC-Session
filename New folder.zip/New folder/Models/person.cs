﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Session_Aleem.Models
{
    public class person
    {
        public int U_ID { get; set; }
        public string username { get; set; }
        [DataType(DataType.Password)]
        public string password { get; set; }
        [DataType(DataType.EmailAddress)]
        public string email { get; set; }

        public bool validate()
        {
            string q = "select count(*) from tbl_person where username='"+username+"' and password='"+password+"'";
            SqlCommand sc = new SqlCommand(q,connection.Get());
            int a = (int)sc.ExecuteScalar();
            if (a>0)
            {
                return true;
            }
            return false;
        }
    }
}