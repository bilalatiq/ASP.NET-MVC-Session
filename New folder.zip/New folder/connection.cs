﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Session_Aleem
{
    public class connection
    {
        static SqlConnection sc;
        public static SqlConnection Get()
        {
            if (sc == null)
            {
                sc = new SqlConnection();
                sc.ConnectionString = "Data Source=WSLAB2025;Initial Catalog=Person;Integrated Security=True";
                sc.Open();
            }
            return sc;
        }
    }
}